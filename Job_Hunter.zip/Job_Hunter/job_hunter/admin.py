from django.contrib import admin
from .models import CV,Job,User

admin.site.register(CV)
admin.site.register(Job)
admin.site.register(User)